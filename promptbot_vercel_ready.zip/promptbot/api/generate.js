export default async function handler(req,res){
try{
const {message}=req.body;

const response=await fetch("https://api.openai.com/v1/chat/completions",{
method:"POST",
headers:{
"Authorization":`Bearer ${process.env.OPENAI_API_KEY}`,
"Content-Type":"application/json"
},
body:JSON.stringify({
model:"gpt-4o-mini",
messages:[
{role:"system",content:"Eres un asistente de WhatsApp profesional."},
{role:"user",content:message}
]
})
});

const data=await response.json();

res.status(200).json({reply:data.choices[0].message.content});

}catch(e){
res.status(500).json({error:"error"});
}
}
