# PromptBot Vercel Ready

Sistema IA WhatsApp listo para GitHub + Vercel.

## Deploy
1. Subir a GitHub
2. Importar en Vercel
3. Añadir OPENAI_API_KEY
4. Deploy
